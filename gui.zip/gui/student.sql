-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 19, 2024 at 10:59 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mydb`
--

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `name` varchar(10) DEFAULT NULL,
  `regno` varchar(20) DEFAULT NULL,
  `math` int(11) DEFAULT NULL,
  `java` int(11) DEFAULT NULL,
  `php` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`name`, `regno`, `math`, `java`, `php`) VALUES
('Ismael', '22RP04197', 87, 98, 65),
('Rosette', '22RP01965', 54, 67, 98),
('Ishimwe', '22rp09876', 100, 100, 100),
('Niyomukiza', '22RP02691', 30, 30, 30),
('Aimable', '2RP09887', 35, 89, 56),
('Vincent', '22RP08734', 45, 76, 98),
('Emmy', '22RP09876', 57, 89, 90),
('Hennriette', '222RP09876', 78, 98, 9);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
